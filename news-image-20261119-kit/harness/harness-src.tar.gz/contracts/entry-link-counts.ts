// A video's counts file: what the grader writes at a program/v1 YouTube entry link's `counts` path under /output
// (contracts/competition.ts ProgramEntryLink.counts) after the entry's runs and before the scorer, so the scorer ranks
// the video on views the house read, never on a number the entry wrote. One JSON object, UTF-8, of exactly these keys:
//
//   format    ENTRY_LINK_COUNTS_FORMAT, exactly
//   platform  'youtube' (the one platform whose link names `counts`)
//   video_id  the video's id, 11 of [A-Za-z0-9_-] (YOUTUBE_VIDEO_ID)
//   url       the video's address as the entry-link record holds it (https)
//   reading   'check', the reading taken when the entry was checked (a dev grade's), or 'deadline', the one taken at
//             the final phase's lock (a final grade's)
//   at        when that reading was taken (RFC 3339 with an offset)
//   video     'public', the video was read and public; 'gone', YouTube answered it absent or not public (the
//             entrant's), every count then null
//   views, likes, comments   each a whole count from 0, or null where YouTube showed none (hidden likes, comments off)
//
// Pure: it imports nothing but zod and the primitives, so every reader may take it without the bundle contract. The
// bundle's scorer mirrors EntryLinkCounts with its language's standard library alone (no import of this file).

import { z } from 'zod';
import { IsoDateTime } from './primitives.ts';

/** A counts file's format tag (EntryLinkCounts.format). */
export const ENTRY_LINK_COUNTS_FORMAT = 'makefun/video-counts/v1';

/** The most bytes a counts file holds: 4 KiB, far past any one the grader writes (an address of at most 2,048 characters and three counts). */
export const ENTRY_LINK_COUNTS_MAX_BYTES = 4 * 1024;

/** A YouTube video's id: 11 letters, digits, underscores and hyphens. */
export const YOUTUBE_VIDEO_ID = /^[A-Za-z0-9_-]{11}$/;

/** Which reading a counts file carries (EntryLinkCounts.reading): the entry's check's (dev), or the final lock's (final). */
export const ENTRY_LINK_COUNTS_READINGS = ['check', 'deadline'] as const;
export type EntryLinkCountsReadingT = (typeof ENTRY_LINK_COUNTS_READINGS)[number];

/** What YouTube answered of the video at that reading (EntryLinkCounts.video). */
export const ENTRY_LINK_COUNTS_VIDEO = ['public', 'gone'] as const;
export type EntryLinkCountsVideoT = (typeof ENTRY_LINK_COUNTS_VIDEO)[number];

/** One count: a whole number from 0, or null where the platform showed none. */
const Count = z.int().min(0).nullable();

/** A video's counts, as the grader writes them for the scorer (the header). */
export const EntryLinkCounts = z
  .strictObject({
    format: z.literal(ENTRY_LINK_COUNTS_FORMAT),
    platform: z.literal('youtube'),
    video_id: z.string().regex(YOUTUBE_VIDEO_ID, "a YouTube video's id is 11 letters, digits, underscores and hyphens"),
    url: z
      .string()
      .max(2048)
      .regex(/^https:\/\/\S+$/, 'the video address is an https URL'),
    reading: z.enum(ENTRY_LINK_COUNTS_READINGS),
    at: IsoDateTime,
    video: z.enum(ENTRY_LINK_COUNTS_VIDEO),
    views: Count,
    likes: Count,
    comments: Count,
  })
  .refine((c) => c.video === 'public' || (c.views === null && c.likes === null && c.comments === null), {
    message: "a video read 'gone' carries no count: views, likes and comments are null",
    // Only on a file whose shape parsed.
    when: (payload) => payload.issues.length === 0,
  });
export type EntryLinkCountsT = z.infer<typeof EntryLinkCounts>;

/**
 * A counts file's text, parsed, or the issues that refuse it: over ENTRY_LINK_COUNTS_MAX_BYTES (refused before it is
 * parsed), not JSON, or not EntryLinkCounts. Pure: it reads only `text`.
 */
export function parseEntryLinkCounts(text: string): { ok: true; counts: EntryLinkCountsT } | { ok: false; issues: string[] } {
  const bytes = new TextEncoder().encode(text).byteLength;
  if (bytes > ENTRY_LINK_COUNTS_MAX_BYTES) return { ok: false, issues: [`${bytes} bytes, over the ${ENTRY_LINK_COUNTS_MAX_BYTES} a counts file holds`] };
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch {
    return { ok: false, issues: ['not JSON'] };
  }
  const r = EntryLinkCounts.safeParse(raw);
  if (r.success) return { ok: true, counts: r.data };
  return { ok: false, issues: r.error.issues.map((i) => `${i.path.length > 0 ? `${i.path.join('.')}: ` : ''}${i.message}`) };
}
